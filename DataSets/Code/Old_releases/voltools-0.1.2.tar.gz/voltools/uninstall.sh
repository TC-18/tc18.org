#!/bin/sh
# This is a generated uninstall script
rm -f /home/aguillau/local/bin/volboundary /home/aguillau/local/bin/volheader /home/aguillau/local/bin/vol2geom /home/aguillau/local/bin/raw2vol /home/aguillau/local/bin/vol2raw
rm -f /home/aguillau/local/man/man1/volboundary.1 /home/aguillau/local/man/man1/volheader.1 /home/aguillau/local/man/man1/vol2geom.1 /home/aguillau/local/man/man1/raw2vol.1 /home/aguillau/local/man/man1/vol2raw.1
