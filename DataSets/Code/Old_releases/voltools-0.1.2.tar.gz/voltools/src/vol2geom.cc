/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of voltools.

    voltools is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    voltools is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with voltools; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <vol.h>

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <unistd.h>

void usage( int errcode = 1 ) {

	fprintf( stderr,
"Usage:\n\
	vol2geom [ -i inputfile ] [ -o outputfile ] [ -O ]\n\
		(default stdin and stdout)\n\
	vol2geom basename\n\
		(converts basename.vol into basename.geom)\n\
	vol2geom -h\n\
		(this help)\n\
\n\
	-P : do NOT optimize : draw every voxel instead of only useful surfaces.\n\
" );
	exit( errcode );

}

int geomview_write_header(FILE *f);
int geomview_write_unit_cube(FILE *f,int x,int y,int z,int r,int v,int b);
int geomview_write_surfel(FILE *f,int x,int y,int z,int xx,int yy,int zz,int r,int v,int b);


int main( int argc, char **argv ) {

	char *file_in = "";
	char *file_out = "/dev/stdout";

	bool optimize = true;

	int curoption;

	// Fast syntax : vol2geom basename
	if (argc == 2 && argv[1][0] != '-') {
		file_in = (char *)malloc( strlen( argv[1] ) + 4 + 1 );
		file_out = (char *)malloc( strlen( argv[1] ) + 4 + 1 );
		assert( file_in != NULL && file_out != NULL );
		// safe
		strcpy( file_in, argv[1] );
		strcpy( file_out, argv[1] );
		strcat( file_in, ".vol" );
		strcat( file_out, ".geom" );
	} else {
		while ((curoption = getopt( argc, argv, "i:o:hP" )) != -1) {
			switch (curoption) {
				case 'i':
					file_in = optarg;
					break;
				case 'o':
					file_out = optarg;
					break;
				case 'P':
					optimize = false;
					break;
				case 'h':
					usage( 0 );
					break;
			}
		}
		if (optind != argc) 
			usage();
	}

	Vol vin( file_in );
	if (!vin.isOK()) {
		fprintf( stderr, "Cannot open %s\n", file_in );
		return 1;
	}
	
	FILE *fout = fopen( file_out, "w" );

	if (fout == NULL) {
		fprintf( stderr, "cannot open file %s for writing !\n", file_out );
		return 2;
	}
	
	int r = 0;
	r += geomview_write_header( fout );

	int maxs[] = { vin.sizeX(), vin.sizeY(), vin.sizeZ() };
	vin.setVolumeCenter( maxs[0]/2, maxs[1]/2, maxs[2]/2 );
	voxel alpha = vin.alpha();
	for (int i = 0; i < maxs[0]; ++i) {
		for (int j = 0; j < maxs[1]; ++j) {
			for (int k = 0; k < maxs[2]; ++k) {
				
				voxel color = vin( i, j, k );
				if (color != alpha) {
					if (!optimize) {
						geomview_write_unit_cube( fout, i, j, k, color, color, color );
					} else {
						// draw surfels when necessary (todo)
						if (i == 0 || vin( i - 1, j, k ) == alpha)
							r += geomview_write_surfel( fout, i - 1, j, k, i, j, k, color, color, color );
						if (j == 0 || vin( i, j - 1 , k ) == alpha)
							r += geomview_write_surfel( fout, i, j - 1, k, i, j, k, color, color, color );
						if (k == 0 || vin( i, j, k - 1 ) == alpha) 
							r += geomview_write_surfel( fout, i, j, k - 1, i, j, k, color, color, color );
						if (i == maxs[0] - 1 || vin( i + 1, j, k ) == alpha)
							r += geomview_write_surfel( fout, i, j, k, i + 1, j, k, color, color, color );
						if (j == maxs[1] - 1 || vin( i, j + 1, k ) == alpha)
							r += geomview_write_surfel( fout, i, j, k, i, j + 1, k, color, color, color );
						if (k == maxs[2] - 1 || vin( i, j, k + 1 ) == alpha)
							r += geomview_write_surfel( fout, i, j, k, i, j, k + 1, color, color, color );
					}
				}
					
			}
		}
	}
	
	r += geomview_write_unit_cube( fout, maxs[0] - 1, 0, 0, 0xFF, 0, 0 );
	r += geomview_write_unit_cube( fout, 0, maxs[1] - 1, 0, 0, 0xFF, 0 );
	r += geomview_write_unit_cube( fout, 0, 0, maxs[2] - 1, 0, 0, 0xFF );
	r += geomview_write_unit_cube( fout, 0, 0, 0, 0xFF, 0xFF, 0xFF );
	
	int exit_code = 0;
	if (r != 0) {
		fprintf( stderr, "%d error occured ... sorry !\n", r );
		exit_code = 1;
	}
	if (fclose( fout ) != 0) {
		perror( "can't close file " );
		exit_code = 1;
	}

	return exit_code;
}

int geomview_write_header(FILE *f)
{
  return fprintf(f,"LIST\n") != 5;
}

int geomview_write_unit_cube(FILE *f,int x,int y,int z,int r,int v,int b)
{
  fprintf(f,"{ OFF\n");
  fprintf(f,"8 6 12\n");
  /* On ecrit les 8 sommets */
  fprintf(f,"%f %f %f\n",x-0.5,y-0.5,z-0.5);
  fprintf(f,"%f %f %f\n",x+0.5,y-0.5,z-0.5);
  fprintf(f,"%f %f %f\n",x+0.5,y-0.5,z+0.5);
  fprintf(f,"%f %f %f\n",x-0.5,y-0.5,z+0.5);
  fprintf(f,"%f %f %f\n",x-0.5,y+0.5,z+0.5);
  fprintf(f,"%f %f %f\n",x+0.5,y+0.5,z+0.5);
  fprintf(f,"%f %f %f\n",x+0.5,y+0.5,z-0.5);
  fprintf(f,"%f %f %f\n",x-0.5,y+0.5,z-0.5);
  fprintf(f,"\n");
  /* et les faces... */
  fprintf(f,"4 0 1 2 3 %d %d %d\n",r,v,b);
  fprintf(f,"4 1 6 5 2 %d %d %d\n",r,v,b);
  fprintf(f,"4 6 5 4 7 %d %d %d\n",r,v,b);
  fprintf(f,"4 4 3 0 7 %d %d %d\n",r,v,b);
  fprintf(f,"4 0 1 6 7 %d %d %d\n",r,v,b);
  fprintf(f,"4 3 2 5 4 %d %d %d\n",r,v,b);
  return fprintf(f,"}\n\n") != 3;
}

int geomview_write_surfel(FILE *f,int x,int y,int z,int xx,int yy,int zz,int r,int v,int b)
{
  float dec;
  float tiny=0.00001;
  
  if (x-xx!=0)
    {
      if (x-xx==1)
    dec=-0.5-tiny;
      else
    dec=0.5+tiny;
      fprintf(f,"{ OFF\n");
      fprintf(f,"4 1 4\n");
      /* On ecrit les 4 sommets */
      fprintf(f,"%f %f %f\n",x+dec,y-0.5,z-0.5);
      fprintf(f,"%f %f %f\n",x+dec,y+0.5,z-0.5);
      fprintf(f,"%f %f %f\n",x+dec,y+0.5,z+0.5);
      fprintf(f,"%f %f %f\n",x+dec,y-0.5,z+0.5);
      fprintf(f,"\n");
      /* et la face... */
      fprintf(f,"4 0 1 2 3 %d %d %d\n",r,v,b);
      return fprintf(f,"}\n\n") != 3;
    }
  if (y-yy!=0)
    {
      if (y-yy==1)
    dec=-0.5-tiny;
      else
    dec=0.5+tiny;                                                                             
      fprintf(f,"{ OFF\n");                                                                   
      fprintf(f,"4 1 4\n");                                                                   
      /* On ecrit les 4 sommets */                                                            
      fprintf(f,"%f %f %f\n",x-0.5,y+dec,z-0.5);                                              
      fprintf(f,"%f %f %f\n",x+0.5,y+dec,z-0.5);                                              
      fprintf(f,"%f %f %f\n",x+0.5,y+dec,z+0.5);                                              
      fprintf(f,"%f %f %f\n",x-0.5,y+dec,z+0.5);                                              
      fprintf(f,"\n");                                                                        
      /* et la face... */                                                                     
      fprintf(f,"4 0 1 2 3 %d %d %d\n",r,v,b);                                                
      return fprintf(f,"}\n\n") != 3;                                                              
    }                                                                                         
  if (z-zz!=0)                                                                                
    {                                                                                         
      if (z-zz==1)                                                                            
    dec=-0.5-tiny;                                                                            
      else                                                                                    
    dec=0.5+tiny;                                                                             
      fprintf(f,"{ OFF\n");                                                                   
      fprintf(f,"4 1 4\n");                                                                   
      /* On ecrit les 4 sommets */                                                            
      fprintf(f,"%f %f %f\n",x-0.5,y-0.5,z+dec);                                              
      fprintf(f,"%f %f %f\n",x+0.5,y-0.5,z+dec);                                              
      fprintf(f,"%f %f %f\n",x+0.5,y+0.5,z+dec);                                              
      fprintf(f,"%f %f %f\n",x-0.5,y+0.5,z+dec);                                              
      fprintf(f,"\n");                                                                        
      /* et la face... */                                                                     
      fprintf(f,"4 0 1 2 3 %d %d %d\n",r,v,b);                                                
      return fprintf(f,"}\n\n") != 3;                                                              
    }                               

	return 1;
}

