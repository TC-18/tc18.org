#!/bin/sh
if [ $# != 1 ]
then
	exit 1
fi

if [ "$1" = "-c" ]
then
	DATE="\""`date`"\""
	version=0.1
	cat > src/config.h << EOF
DATE=$DATE
VERSION=$version
EOF
	exit 0
else 
	. ./makefile.in
	. ./src/config.h || exit 1
fi

PREFIX=$1
saved_pwd=`pwd`

rm -rf tmp

mkdir -p $PREFIX/Libvol
mkdir -p $PREFIX/Voltools
mkdir -p $PREFIX/Volgen
mkdir -p tmp

cp -rf src/Libvol src/Voltools src/Volgen tmp
cp -r ../libvol/tutorial tmp/Libvol


find tmp -name "*.html" |
while read m 
do 
	echo updating $m ; 
	sed "s/__DATE__/$DATE/g;s/__VERSION__/$VERSION/g;s!__VOL_DOX__!$VOL_DOX!g" "$m" > /tmp/m.$$ && mv /tmp/m.$$ $m ; 
done   

cp -rf tmp/* $PREFIX

rm -rf $PREFIX/*/man

mkdir -p $PREFIX/Libvol/man
mkdir -p $PREFIX/Voltools/man
mkdir -p $PREFIX/Volgen/man

for i in ../libvol/src/man*/* 
do
	name=`basename $i .\[0-9\]`
	echo "installing man of $name"
	/usr/bin/man $name 2>/dev/null | man2html -sun > $PREFIX/Libvol/man/$name-man.html
done

for i in ../voltools/src/man*/*
do
	name=`basename $i .\[0-9\]`
	echo "installing man of $name"
	/usr/bin/man $name 2>/dev/null | man2html -sun > $PREFIX/Voltools/man/$name-man.html
done

for i in ../volcompose/src/man*/*
do
	name=`basename $i .\[0-9\]`
	echo "installing man of $name"
	/usr/bin/man $name 2>/dev/null | man2html -sun > $PREFIX/Volgen/man/$name-man.html

done

cd tmp/Libvol/ && tar cf $PREFIX/Download/tutorial.tar tutorial && gzip -f $PREFIX/Download/tutorial.tar; cd $saved_pwd
rm -rf tmp

#cp src/Volgen/vol-and-geom/* $PREFIX/../3D_binary/
