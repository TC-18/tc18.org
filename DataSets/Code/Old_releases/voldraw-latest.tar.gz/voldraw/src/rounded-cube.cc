/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of voldraw.

    voldraw is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    voldraw is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with voldraw; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include "rounded-cube.h"
#include "utils.h"

void RoundedCube::printCaracteristics() {


}

void RoundedCube::printParams() {

	printf( "len = %e;\n", r );

}

Vol RoundedCube::initDraw() {

	return Vol( (int)5*r + 1, (int)5*r + 1, (int)5*r + 1, 0 );

}

bool RoundedCube::pointIn( coord_t x, coord_t y, coord_t z, voxel *color ) {

	number_t nx = (number_t)x, ny = (number_t)y, nz = (number_t)z;
	
	if (pow(nx, 6.) + pow(ny, 6.) + pow(nz, 6.) < pow(r, 6.)) {
		*color = 0x20;
		return true;
	}

	return false;

}

void RoundedCube::endDraw( Vol &v ) {

	v.symetry( (int)2*r + 1, (int)2*r + 1, (int)2*r + 1 );

}
