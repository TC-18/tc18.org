/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of voldraw.

    voldraw is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    voldraw is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with voldraw; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include <math.h>
#include <stdio.h>

#include "utils.h"

// This code is the C++ translation of Garry Tee ( tee@math.auckland.ac.nz ) pascal code
// available at <http://www.citr.auckland.ac.nz/dgt/Source_Code.php?id=2>

// Written by Alexis Guillaume <aguillau@liris.univ-lyon2.fr>

// Integrates f on [a,b], by Romberg's method, within the criterion eps
static double Romberg( double (*f)(double, double m), double m, double a, double b, double eps ) {

	const int size = 20;

	long i, j, n;
	double h, s, j4;
	double RR[size][size];

	i = 0;
	n = 1;
	h = b - a;
	s = (f(a, m) + f(b, m)) / 2;
	RR[0][0] = h*s;
	
	do {
		++i;
		for (j = 1; j <= n; ++j)
			s += f( a + (j - 0.5)*h, m );
		n *= 2;
		h /= 2;
		RR[i][0] = h*s;
		j4 = 1;
		for (j = 1; j <= i; ++j) {
			j4 /= 4;
			RR[i][j] = (RR[i][j - 1] - j4*RR[i - 1][j - 1])/(1 - j4);
		}	
	} while (abs(RR[i][i] - RR[i - 1][i - 1]) >= eps);

	return RR[i][i];
}

static double Delta1( double t, double m ) {
	return 1 / sqrt( 1 - m * square( sin(t) ) );
}
// Yields Legendre's Incomplete Elliptic Integral of the First Kind, by numerical integration.  F  =  int_0^(theta) Delta1(t) dt
static double Fsn( double theta, double m ) {
	return Romberg( &Delta1, m, 0, theta, 1e-14);
}

static double Delta2( double t, double m ) {

		return sqrt( 1 - m * square( sin(t) ) );

}

static double Esn( double phi, double m ) {

// Yields Legendre's Incomplete Elliptic Integral of the First Kind, by
// numerical integration.       E = int_0^theta Delta2(t) dt

	return Romberg( &Delta2, m, 0, phi, 1e-14);
	
}

double Fts( double s2, double m ) {

//  Fts  = F(phi | m) / sin(phi),  where s2 = sin^2 phi. Write x = sin phi.
//Now,  F(phi|m)  =  F(x;m) = int_0^x dt/sqrt((1-tt)(1-mtt)).   
//(1-tt)^(-1/2) = 1 + t ^ 2 / 2 + t ^ 4 3 / 8 + t^6 5 / 16 + ~J
//(1-mtt)^(-1/2) = 1 + mt ^ 2 / 2 + m^2 t ^ 4 3 / 8 + m^3 t^6 5 / 16 + ~J
//Therefore, 1/~H = 1 + t^2(1+m)/2 + t^4(3+2m+3m^2)/40
//                                 + t^6(5+3m+3m^2+5m^3)/112 + ~J
//Integrating t from 0 to x and then dividing by x,  we get that Fts = F(x;m)/x  
//    = 1 + x^2 (1+m)/6 + x^4 (3+2m+3m^2)/40 +  x^6 (5+3m+3m^2+5m^3)/112 + ...
//The coefficient of x^6 is <= 1/7; and hence with |x|<1e-3, the error is <1.5e-1
	
	const double delta = 1e-6;
	double x;

	if (s2 >= delta) {
		x = sqrt(s2);
		return Fsn( asin(x), m ) / x;
	} 
	
	return  1 + s2 * ((1 + m) / 6 + s2 * (3 + m * (2 + 3 * m) / 40));

}

// Original name in Garry Tee : Surfacearea
double EllipsoidArea( double p, double q, double r ) {

	const double eps = 1e-17;
	double a, b, c, ca, cb, cr, theta, m;

	c = min( p, min( q, r ) );
	a = max( p, max( q, r ) );
	b = max( min( p, q ), max( min(p, r), min(q, r) ) );
	// now a >= b >= c !
//	fprintf( stderr, "a = %e, b = %e, c= %e\n", a, b, c );

	ca = 1 - square( c/a ); // ca = sin^2 theta
	cb = 1 - square( c/b );
	if (ca < eps) { 		// Sphere a=b=c gives m = 0/0    Beware!
// If c/a = 1-d, where d<<1 for a near-sphere, then ca = d(2-d), and cr and theta are both
// close to sqrt(2d).  As b increases from c to a, m decreases from 1 to 0.
// The surface area varies continuously with a, b and c; but m is ill-conditioned for
// a near-sphere. Roundoff could produce m outside [0,1].
// For small theta, F(theta|m) and E(theta|m) are both very close to theta, for all m in [0,1]
		m = 0.5;
	} else {
		m = cb/ca;
	}
	cr = sqrt(ca);
	theta = asin(cr);
	
	return 2 * M_PI * (square(c) * (1 + Fts(ca, m) * b / a) + Esn(theta, m) * a * b * cr);

}
