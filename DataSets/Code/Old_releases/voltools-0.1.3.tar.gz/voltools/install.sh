#!/bin/sh

[ $# != 1 ] && exit 1

if [ "$1" = "-c" ]
then
    date=\"`date`\"
    version=0.1.1
    cat > src/config.h << EOF
DATE=$date
VERSION=$version
EOF
    exit 0  
else 
    . ./src/config.h || exit 1
fi

PREFIX=$1

mkdir -p $PREFIX
mkdir -p $PREFIX/bin
mkdir -p $PREFIX/include
mkdir -p $PREFIX/lib
mkdir -p $PREFIX/man/man1

mkdir -p tmp
mkdir -p tmp/bin
mkdir -p tmp/include
mkdir -p tmp/lib
mkdir -p tmp/man/man1

cp src/volboundary src/volarith src/raw2vol src/vol2raw tmp/bin
cp src/man1/* tmp/man/man1
cp src/vol2geom src/volheader tmp/bin

find tmp -name "*.html" -o -name "*.1" -o -name "*.7" | \
while read m ; \
do \
	echo updating $m ; \
	sed "s/__DATE__/$DATE/g;s/__VERSION__/$VERSION/g" "$m" > /tmp/m.$$ && mv /tmp/m.$$ $m ; \
done   

cp tmp/bin/volboundary tmp/bin/volarith tmp/bin/raw2vol tmp/bin/vol2raw $PREFIX/bin
cp tmp/man/man1/* $PREFIX/man/man1
cp tmp/bin/vol2geom tmp/bin/volheader $PREFIX/bin

cat > uninstall.sh << EOF
#!/bin/sh
# This is a generated uninstall script
rm -f $PREFIX/bin/volboundary $PREFIX/bin/volheader $PREFIX/bin/vol2geom $PREFIX/bin/raw2vol $PREFIX/bin/vol2raw
rm -f $PREFIX/man/man1/volboundary.1 $PREFIX/man/man1/volheader.1 $PREFIX/man/man1/vol2geom.1 $PREFIX/man/man1/raw2vol.1 $PREFIX/man/man1/vol2raw.1
EOF
chmod +x uninstall.sh

rm -rf tmp
