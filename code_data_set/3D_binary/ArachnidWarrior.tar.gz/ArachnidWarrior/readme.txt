
This object was converted from a triangle mesh in LWO (LightWave5 object)
format. This object is a free object obtained from Internet. It represents an
arachnid warrior from Paul Verhoeven's film Starship Troopers

The converter was made in 2002 by Thierry Baud and Djemel Guizani when they
were in their 3rd year of student at the ES2I/ESIL (Ecole Superieure
d'Ingenieurs en Informatique at the Ecole Superieure d'Ingenieurs de Luminy) at
the Universite de la Mediterrannee in Marseille France. The converter gives a
set of points forming the discrete surface of the set of triangles. The
algorithm used is rather simple and stupid:
Lets consider a triangle (a,b,c).
 - first, an edge of the triangle (say [ab]) is drawn using Bresenham's
   algorithm.
 - for each of the obtained points x forming this discrete edge [ab],
   Bresenham's algorithm is used to draw discrete lines [xc]. This way the
   triangle is filled.

This discrete "crust" (made of 1-colored points) was then filled using the
following scheme:
 - fill the exterior of the crust with a different color (say 2).
 - change 1-points to background (0-points).
 - negate this volume.
It is much more simpler to fill the volume this way (by filling its exterior)
than filling its interior since the latter gives of lots of small holes in the
object.

This discretisation process was used from the LWO object to each of the 3D
discrete image.

May the 24th, 2003

E.Remy
