#include <vol.h>

#include <time.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

int main( int argc, char **argv ) {

	for (int i = 1; i < argc; ++i ) {

		int len = strlen( argv[i] );
		
		Vol v;

		if (len < 4 || (strcmp( argv[i] + len - 4, ".raw" ) != 0 
				&& strcmp( argv[i] + len - 4, ".vol" )) != 0 ) {
			fprintf( stderr, "Cannot find format of %s\n, skipping ...", argv[i] );
			continue;
		} else if (strcmp( argv[i] + len - 4, ".raw" ) == 0) {
			v = Vol( argv[i], false, 0 );
		} else {
			v = Vol( argv[i] );
		}
			
		if (!v.isOK()) {
			fprintf( stderr, "Cannot load %s, skipping ...\n", argv[i] );
			continue;
		}
			
		if (v.getHeaderValue( "Rotated" ) != NULL ) {

			int date;
			int errcode = v.getHeaderValueAsInt( "Rotation-Date", &date );

			fprintf( stderr, "The file %s is already a rotated file (%s), skipping ....\n", argv[i], 
						(errcode ? "no date found" : ctime( (time_t*)&date )) );

		} else {
			char *newname = new char[ len - 4 + strlen(".rot.vol") + 1 ];
		
			if (newname == NULL) {
				fprintf( stderr, "cannot allocate memory .. skipping.\n" );
			} else {
				v.rotate( M_PI/4, 0, 0 );
				strcpy( newname, argv[i] );
				strcpy( newname + len - 4, ".rot.vol" );

				v.setHeaderValue( "Rotated", "yes" );
				v.setHeaderValue( "Rotation-Date", (int)time(NULL) );
				
				v.dumpVol( newname );

				delete []newname;
			}

		}

	}

	return 0;
}
