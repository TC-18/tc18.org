#include <vol.h>
#include <stdio.h>

int main() {

	Vol myvolume( 16, 16, 16, 0 );

	printf( "Here are the bounds of my volume object :\n\
			X : [ %d, %d [,\n\
			Y : [ %d, %d [,\n\
			Z : [ %d, %d [.\n",
			myvolume.minX(), myvolume.maxX(),
			myvolume.minY(), myvolume.maxY(),
			myvolume.minY(), myvolume.maxY()
	);

	for (int i = myvolume.minX(); i < myvolume.maxX(); ++i) {                               
		for (int j = myvolume.minY(); j < myvolume.maxY(); ++j) {
			for (int k = myvolume.minZ(); k < myvolume.maxZ(); ++k) {
				if (i*j*k >= 0) {
					myvolume(i, j, k) = 100;
				}
			}
		}
	}

	myvolume.dumpVol( "hello.vol" );

	return 0;
				
}
