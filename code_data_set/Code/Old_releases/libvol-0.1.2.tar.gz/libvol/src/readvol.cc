/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of libvol.

    libvol is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    libvol is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with libvol; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include "vol.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

int Vol::readVolData( FILE *fin ) {

	
	// Read header
	// Buf for a line 
	char buf[128];
	int linecount = 1;
	int fieldcount = 0;
	
	// Read the file line by line until ".\n" is found
	for (	char *line = fgets( buf, 128, fin );
			line && strcmp( line, ".\n" ) != 0 ; 
			line = fgets( line, 128, fin ), ++linecount
		) {

		if (line[strlen(line) - 1] != '\n') {
			fprintf(stderr, "LIBVOL : Line %d too long\n", linecount );
			return 1;
		}

		int i;
		for (i = 0; line[i] && line[i] != ':'; ++i);

		if (i == 0 || i >= 126 || line[i] != ':') {
			fprintf( stderr, "LIBVOL : Invalid header read at line %d\n", linecount );
		} else {
		
			if (fieldcount == MAX_HEADERNUMLINES) {
				fprintf( stderr, "LIBVOL : Too many lines in HEADER, ignoring\n" );
				continue;
			}
			if (fieldcount > MAX_HEADERNUMLINES)
				continue;

			// Remove \n from end of line
			if (line[ strlen(line) - 1 ] == '\n')
				line[ strlen(line) - 1 ] = 0;

			// hack : split line in two str ...
			line[i] = 0;
			header[ fieldcount++ ] = HeaderField( line, line + i + 2 ); 
												// +2 cause we skip the space
												// following the colon
		}

	}

	// Check required headers
	for (int i = 0; requiredHeaders[i]; ++i) {
		if (getHeaderField( requiredHeaders[i] ) == -1) {
			fprintf( stderr, "LIBVOL : Required Header Field missing : %s\n", requiredHeaders[i] );
			return 1;
		}
	}
	// Check endian
	if (strcmp( endian.i_endian.ci, getHeaderValue( "Int-Endian" )) != 0 || 
		strcmp( endian.v_endian.cv, getHeaderValue( "Voxel-Endian" )) != 0) {
		fprintf( stderr, "LIBVOL : This file has incompatible endianess. Convertion to be implemented !\n");
		return 1;
	}
	
	return readRawData( fin, true, alpha() );

}


int Vol::readRawData( FILE *fin, bool headerInited, voxel defaultAlpha ) {

	int count = 0;

	// Size of the volume
	count += fread( &sx, sizeof(int), 1, fin );
	count += fread( &sy, sizeof(int), 1, fin );
	count += fread( &sz, sizeof(int), 1, fin );

	if (count != 3) {
		fprintf( stderr, "LIBVOL : can't read file (raw header)\n" );
		return 1;
	}

	if (headerInited) {
		
		// The raw header contains the volume size too
		int tmpsx = -1, tmpsy = -1, tmpsz = -1;
	
		getHeaderValueAsInt("X", &tmpsx);
		getHeaderValueAsInt("Y", &tmpsy);
		getHeaderValueAsInt("Z", &tmpsz);

		if (sx != tmpsx || sy != tmpsy || sz != tmpsz) {
				fprintf( stderr, "LIBVOL : Incoherent vol header with raw header !\n" );
				return 1;
		}
	
		int voxsize;
		if (getHeaderValueAsInt( "Voxel-Size", &voxsize ) == 0 && voxsize != sizeof(voxel)) {
			fprintf( stderr, "LIBVOL : This file was generated with a voxel-size that we do not support.\n");
			return 1;
		}
	
	}
	
	// We should have a useless \n in the file at this point
	char tmp;
	count = fread( &tmp, sizeof(char), 1, fin );

	if (count != 1 || tmp != '\n') {
		fprintf( stderr, "LIBVOL : I thouhgt I would have read a \\n !\n" );
		return 1;
	}

	// now read the raw data
	total = sx * sy * sz;
	try {
		data = new voxel[ sx * sy * sz ];
	} catch (...) {
		fprintf( stderr, "LIBVOL : not enough memory\n" );
		return 1;
	}
	
	count = fread( data, sizeof(voxel), total, fin );	

	if (count != total) {
		fprintf( stderr, "LIBVOL : can't read file (raw data) !\n" );
		return 1;
	}

	// Now do some initializations 
	// (if a header is not found, the second param is not changed)
	getHeaderValueAsInt( "Center-X", &cx );
	getHeaderValueAsInt( "Center-Y", &cy );
	getHeaderValueAsInt( "Center-Z", &cz );

	// If header has not been inited, do it !
	if (!headerInited) {
		setHeaderValue( "X", sx );
		setHeaderValue( "Y", sy );
		setHeaderValue( "Z", sz );
		setHeaderValue( "Alpha-Color", (int)defaultAlpha );
		setHeaderValue( "Voxel-Size", (int)sizeof(voxel) );
		setHeaderValue( "Int-Endian", endian.i_endian.ci );
		setHeaderValue( "Voxel-Endian", endian.v_endian.cv );
		setHeaderValue( "Res-X", 1 );
		setHeaderValue( "Res-Y", 1 );
		setHeaderValue( "Res-Z", 1 );
	}

	return 0;

}

const char *Vol::requiredHeaders[] = {
	"X", "Y", "Z", "Voxel-Size", "Res-X", "Res-Y", "Res-Z", "Int-Endian", "Voxel-Endian", "Alpha-Color", NULL
};
