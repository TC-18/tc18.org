/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of volcompose.

    volcompose is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    volcompose is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with volcompose; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include "figure.h"

#include <math.h>
#include <stdio.h>
#include <assert.h>
#include <limits.h>
#include <values.h>

Figure::Figure( double rrx, double rry, double rrz ) :
	drawAxis( false ),
	rx(rrx), ry(rry), rz(rrz)
{

}

Vol Figure::draw( const char *sigFileName ) {

	if (sigFileName == NULL) {
		dumpFile = NULL;
	} else if (sigFileName[0] == 0) {// "" string
		dumpFile = stdout;
	} else {
		dumpFile = fopen( sigFileName, "w" );
		if (!dumpFile) {
			fprintf( stderr, "Warning : can't open %s for writing !\n", sigFileName );
		}
	}

	Vol v = draw( dumpFile );

	if (sigFileName != NULL && sigFileName[0] == 0)
		fclose( dumpFile );

	return v;
}

Vol Figure::draw( FILE *infile ) {

	dumpFile = infile;

	if (dumpFile != NULL) {
		fprintf( dumpFile, "%s untitled {\n", type() );
		fprintf( dumpFile, "\trotation-X = %e;\n\trotation-Y = %e;\n\trotation-Z = %e;\n", rx, ry, rz );
		fprintf( dumpFile, "\tparams {\n" );
		printParams();
		fprintf( dumpFile, "}\n" );
		fprintf( dumpFile, "/*\ncarateristics {\n" );
		printCaracteristics();
		fprintf( dumpFile, "}\n" );
		fprintf( dumpFile, "points {\n" );
	}
	
	Vol v = initDraw();
	defaultMethodDraw( v );
	endDraw( v );
	
	if (dumpFile != NULL) {
		fprintf( dumpFile, "}\n*/};\n" );
	}
	
	if (rx || ry || rz) 
		v.rotate( rx, ry, rz );
	if (drawAxis)
		v.drawAxis();
	return v;
}

void CartesianFigure::defaultMethodDraw( Vol &v ) {

	int mins[] = { getMinX( v ), getMinY( v ), getMinZ( v ) };
	int maxs[] = { getMaxX( v ), getMaxY( v ), getMaxZ( v ) };

	voxel color = 0x7F;

	for (int i = mins[0]; i < maxs[0]; ++i) {
		for (int j = mins[1]; j < maxs[1]; ++j) {
			for (int k = mins[2]; k < maxs[2]; ++k) {
				if (pointIn( i, j, k, &color )) {
					v(i, j, k) = color;
				}
			}
		}
	}

}

void ParametricFigure::defaultMethodDraw( Vol &v ) {

	number_t mint = getMinTheta();
	number_t maxt = getMaxTheta();
	number_t stept = getStepTheta();
	
	if (stept == 0)
		stept = maxt + 1;
	
	number_t minp = getMinPhi();
	number_t maxp = getMaxPhi();
	number_t stepp = getStepPhi();

	if (stepp == 0)
		stepp = maxp + 1;

	for (number_t theta = mint; theta <= maxt; theta += stept) {
		for (number_t phi = minp; phi <= maxp; phi += stepp ) {
			drawPoints( v, theta, phi );
		}
	}

}

/*
void ParametricFigure::get_point( number_t theta, number_t phi, coord_t *x, coord_t *y, coord_t *z, voxel *color ) {

	number_t dx, dy, dz;
	get_point( theta, phi, &dx, &dy, &dz, color );
	*x = (coord_t)dx;
	*y = (coord_t)dy;
	*z = (coord_t)dz;

}
*/
