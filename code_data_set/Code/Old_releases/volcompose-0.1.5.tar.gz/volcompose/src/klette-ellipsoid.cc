/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of volcompose.

    volcompose is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    volcompose is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with volcompose; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include "klette-ellipsoid.h"
#include "utils.h"
#include "surface.h"

#include <stdio.h>
#include <assert.h>

KletteEllipsoid::KletteEllipsoid( number_t n1, number_t n2, number_t n3,
					number_t rx, number_t ry, number_t rz ) :
	Figure( rx, ry, rz ),
	ba( n1 ), bb( n2 ), bc( n3 ), la( n1/2. ), lb( n2/2. ), lc( n3/2. )

{

	if (n1 <= 0 || n2 <= 0 || n3 <= 0) {
		throw InvalidParametersException( "KletteEllipsoid : every parameter must be greater than zero.");
	}
	 

}

Vol KletteEllipsoid::initDraw( ) {

	int m = (int)max( ba, max(bb, bc) );
	return Vol( m*2 + 1, m*2 + 1, m*2 + 1, 0 );

}

void KletteEllipsoid::endDraw( Vol &v ) {

}

void KletteEllipsoid::printParams() {

	fprintf( dumpFile, "a = %e; b = %e; c = %e;\n", 
				ba, bb, bc
			);

}

number_t KletteEllipsoid::area() {

	return EllipsoidArea( ba, bb, bc )/2. - EllipsoidArea( la, lb, lc )/2.;

}

void KletteEllipsoid::printCaracteristics() {

	fprintf( dumpFile, "area = %e\n", area() );

}

bool KletteEllipsoid::pointIn( coord_t cox, coord_t coy, coord_t coz, voxel *color ) {

	if (inKletteEllipsoid( (number_t)cox, (number_t)coy, (number_t)coz )) {
		*color = 0x60;
		return true;
	}

	return false;
}

bool KletteEllipsoid::inKletteEllipsoid( number_t x, number_t y, number_t z ) {

	number_t sx = square(x), sy = square(y), sz = square(z);
	number_t lsx = square( x ), lsy = square( y ), lsz = square( z - bc + lc + 1);
	return (sx/square(ba) + sy/square(bb) + sz/square(bc) < 1.0 &&
			lsx/square(la) + lsy/square(lb) + lsz/square(lc) >= 1.0 );

}
