/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of volcompose.

    volcompose is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    volcompose is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with volcompose; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#ifndef ELLIPSOID
#define ELLIPSOID

#include "figure.h"

class Ellipsoid : public ParametricAndCartesianFigure {

protected:
	number_t 			a, b, c;
	number_t			min_Curvature, max_Curvature;

	// Cartesian
	virtual bool		pointIn( coord_t, coord_t y, coord_t z, voxel *color );
//	virtual void		init_precision( int, int, int ) {};

	// Parametric
//	virtual void        get_point( number_t theta, number_t phi, number_t *x, number_t *y, number_t *z, voxel *color );
	virtual void		drawPoints( Vol &v, number_t theta, number_t phi );

	virtual number_t	gaussianCurvature( number_t, number_t y, number_t z );
	
	void        		initCurvature();


	virtual coord_t		getMinX( Vol &v ) { return 0; }
	virtual coord_t		getMinY( Vol &v ) { return 0; }
	virtual coord_t		getMinZ( Vol &v ) { return 0; }


	bool				inEllipsoid( coord_t cox, coord_t coy, coord_t coz );
	// All arguments should be positive
	void				intersections( coord_t cox, coord_t coy, coord_t coz, number_t r[12][2] );
	// 	Position 					Intersections with line
	//  ----------------------------------------------------
	//	r[0] : 						Y = coy - 1/2, Z = coz - 1/2
	// 	r[1] :						Y = coy + 1/2, Z = coz - 1/2
	//	r[2] :						Y = coy - 1/2, Z = coz + 1/2
	//	r[3] : 						Y = coy + 1/2, Z = coz + 1/2
	//	r[4] : intersections with 	X = cox - 1/2, Z = coz - 1/2
	// 	r[5] : 						X = cox + 1/2, Z = coz - 1/2
	//	r[6] :						X = cox - 1/2, Z = coz + 1/2
	//	r[7] :						X = cox + 1/2, Z = coz + 1/2
	// 	r[8] : 						X = cox - 1/2, Y = coy - 1/2
	// 	r[9] : 						X = cox + 1/2, Y = coy - 1/2
	// 	r[10] : 					X = cox - 1/2, Y = coy + 1/2
	//	r[11] :						X = cox + 1/2, Y = coy + 1/2

	bool				intersectionOf( number_t *x, number_t *y, number_t *z, int intersection_num, number_t intersection[12][2] );

	// Solves (V+x)^2/v^2 + A^2/a^2 + B^2/b^2 - 1 == 0 (x is the only variant)
	void 				solve( number_t V, number_t v, number_t A, number_t a, number_t B, number_t b, number_t imin, number_t imax, number_t *x1, number_t *x2 );

	virtual Vol			initDraw( );
			void		dumpCartesianPoint( coord_t x, coord_t y, coord_t z, number_t t[12][2] );
	virtual void		endDraw( Vol &v );

	virtual void		printCaracteristics();
	virtual void 		printParams();	


	virtual number_t	area();

	
public:
	virtual const char *type() { return "Ellipsoid"; }

	virtual number_t	getMinTheta() {return 0.0;}
	virtual number_t	getMaxTheta() {return M_PI/2;}
	virtual number_t	getMinPhi() {return 0.0;}
	virtual number_t	getMaxPhi() {return M_PI/2;}

	virtual number_t	getMaxCurvature();
	virtual number_t	getMinCurvature();

	// parametric equation : x^2/a^2 + y^2/b^2 + z^2/c^2 == 1
	Ellipsoid( number_t a, number_t b, number_t c, number_t rx = 0.0, number_t ry = 0.0, number_t rz = 0.0 );
	~Ellipsoid() {};
};

#endif
