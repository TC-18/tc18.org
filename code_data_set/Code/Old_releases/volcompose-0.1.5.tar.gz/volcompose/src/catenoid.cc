/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of volcompose.

    volcompose is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    volcompose is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with volcompose; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include <assert.h>
#include <limits.h>

#include "catenoid.h"
#include "utils.h"

Catenoid::Catenoid( number_t cc, number_t rx, number_t ry, number_t rz) : 
	Figure(rx, ry, rz), 
	c(cc) 
{
	
	if (c <= 0) {
		throw InvalidParametersException( "Catenoid : c must be strictly greater than zero." );
	}

}

void Catenoid::drawPoints( Vol &v, number_t theta, number_t phi ) {

	number_t 	nx = c*cosh( phi/c )*cos(theta),
				ny = c*cosh( phi/c )*sin(theta);
	coord_t mx = (coord_t)nx;
	coord_t y = (coord_t)ny;
	coord_t z = (coord_t)phi;

	if (dumpFile != NULL) {
		dumpPoint( nx, ny, phi, theta, phi );
	}

	if (mx > maxx) maxx = mx;
	if (y > maxy) maxy = y;
	if (z > maxz) maxz = z;
	for (coord_t x = 0; x < (int)mx; ++x) {
		v( x, y, z ) = 0x60;
	}

}

void Catenoid::dumpPoint( number_t x, number_t y, number_t z, number_t theta, number_t phi ) {

	if (lastx != (int)x || lasty != (int)y || lastz != (int)z) {
		
		if (!isVerbose() && count != 0) {
			fprintf( dumpFile, "%e\n", sum_gauss/count );
		}
		
		fprintf( dumpFile, "%d\t%d\t%d%s", (int)x, (int)y, (int)z, isVerbose() ? "\n" : "\t" );
		
		lastx = (int)x;
		lasty = (int)y;
		lastz = (int)z;
		
		sum_gauss = 0;
		count = 0;
	}

	number_t g = gaussianCurvature( phi );
	if (isVerbose())
		fprintf( dumpFile, "\t\t\t%e\t%e\t%e\t%e\n", x, y, z, gaussianCurvature( phi ) );
	++count;	
	sum_gauss += g;
}

Vol Catenoid::initDraw( ) {
	maxx = maxy = maxz = -1;
	lastx = lasty = lastz = INT_MAX;
	sum_gauss = 0;
	count = 0;
	
	if (dumpFile != NULL) {
		if (isVerbose())
			fprintf( dumpFile, "X\tY\tZ\tx\ty\tz\tgauss\n");
		else 
			fprintf( dumpFile, "X\tY\tZ\tmean(gauss)\n" );
	}
	return Vol( c*4, c*4, c*4, 0 );
}

void Catenoid::endDraw( Vol &v ) {

	if (dumpFile != NULL && !isVerbose()) {
		fprintf( dumpFile, "%e\n", sum_gauss/count );
	}
	v.symetry( maxx, maxy, maxz );	

}

void Catenoid::printCaracteristics() {
	
}

void Catenoid::printParams() {
	fprintf( dumpFile, "c = %e;\n", c );
}

number_t Catenoid::gaussianCurvature( number_t phi ) {

	return pow( 1/cosh( phi/c ), 4.)/square(c);

}
