/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of volcompose.

    volcompose is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    volcompose is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with volcompose; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#ifndef CATENOID
#define CATENOID

#include "figure.h"

class Catenoid : public ParametricFigure {

protected:
	number_t			c;
	
	// http://mathworld.wolfram.com/Catenoid.html
	// Theta is u
	virtual number_t	getMinTheta() { return /*0.0*/0.0; }
	virtual number_t	getMaxTheta() { return /*2*M_PI*/M_PI/2; }

	// Phi is v
	virtual number_t	getMinPhi() { return /*-c*/0.0; }
	virtual number_t	getMaxPhi() { return c; }
//	virtual void        get_point( number_t theta, number_t phi, number_t *x, number_t *y, number_t *z, voxel *color );

	// TODO : find a good step for phi and theta (with big values of c, there are "holes")

	virtual void		drawPoints( Vol &v, number_t theta, number_t phi );

	virtual Vol			initDraw();
	virtual void		endDraw( Vol &v );
	
	virtual void		printCaracteristics();
	virtual void		printParams();
	
	coord_t				maxx, maxy, maxz;
	
	int					lastx, lasty, lastz;
	// Variables for computing the mean gaussian curvature on a discrete point
	number_t			sum_gauss;
	int					count;
	void				dumpPoint( number_t x, number_t y, number_t z, number_t theta, number_t phi );

	number_t			gaussianCurvature( number_t phi );


public:
	virtual const char *type() { return "Catenoid"; }

	Catenoid( number_t cc, number_t rx = 0.0, number_t ry = 0.0, number_t rz = 0.0 );
	virtual ~Catenoid() {};

};

#endif
