/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of volcompose.

    volcompose is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    volcompose is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with volcompose; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include <vol.h>

#include <limits.h>
#include <values.h>
#include <stdio.h>

#include <unistd.h>

#include "desc.h"

#include "figure.h"
#include "ellipsoid.h"
#include "cube.h"
#include "catenoid.h"
#include "sphere.h"
#include "rounded-cube.h"

const char *sigdestfile, *voldestfile;
extern FILE *yyin;

//static const double A = 10.5, B = 15.34, C = 20.19;
static const double A = 10, B = A*2, C = A*3;
static const double RX = 0, RY = RX, RZ = RX;

void usage( int errcode = badCommandLine ) {
	fprintf( stderr, "Usage :\n\tvolcompose [ -i inputfile (default stdin) ] [ -v vol outputfile (default /dev/null) ] [ -s sig output file (default /dev/null) ]\n\tvolcompose -h : this help\n" );
	exit( errcode );	

}

int main( int argc, char **argv ) {

	int curoption;

	if (isatty(1) && isatty(0)) {
		printf( "Volcompose v%s (%s).\nThis is free software; see the source for copying conditions.\nThere is NO warranty; not even for MERCHANTABILITY or FITNESS\nFOR A PARTICULAR PURPOSE.\n\n", VERSION, DATE );
	}

	voldestfile = NULL;
	sigdestfile = NULL;
	while ((curoption = getopt( argc, argv, "i:v:s:h")) != -1) {
		switch (curoption) {
			case 'v':
				if (strcmp( optarg, "-" ) == 0) {
					voldestfile = "/dev/stdout";
				} else {
					voldestfile = optarg;
				}
				break;
			case 's':
				if (strcmp( optarg, "-" ) == 0)
					sigdestfile = "/dev/stdout";
				else 
					sigdestfile = optarg;
				break;
			case 'i':
				yyin = fopen( optarg, "r" );
				if (!yyin) {
					fprintf( stderr, "%s : No such file or directory.\n", optarg );
					return badInputFile;
				}
				break;
			case 'h':
				usage( noError );
				break;
		}
	}

	if (optind != argc) {
		usage();
	}

	yyparse();

	return parseErrCode;
}
