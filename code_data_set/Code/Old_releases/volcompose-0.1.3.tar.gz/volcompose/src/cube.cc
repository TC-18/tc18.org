/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of volcompose.

    volcompose is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    volcompose is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with volcompose; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include "cube.h"
#include "utils.h"

#include <stdio.h>
#include <assert.h>

Cube::Cube( int l, number_t rx, number_t ry, number_t rz ) :
	Figure( rx, ry, rz ),
	len( l ) {

	assert( l >= 2 );

}

Vol Cube::initDraw( ) {

	Vol v( len*2, len*2, len*2, 0 );
	v.setVolumeCenter( len/2, len/2, len/2 );
	return v;
}

void Cube::endDraw( Vol &v ) {
}

void Cube::defaultMethodDraw( Vol &v ) {

	coord_t max = (coord_t)len;
	for (coord_t a = 0; a < max; ++a) {
		for (coord_t b = 0; b < max; ++b) {
			for (coord_t c = 1; c < max - 1; ++c) {
				v(a, b, c) = 0x60;
			}
			v(a, b, 0) = 0x60;
			v(a, 0, b) = 0x60;
			v(0, a, b) = 0x60;
			v(a, b, max - 1) = 0x60;
			v(a, max - 1, b) = 0x60;
			v(max - 1, a, b) = 0x60;
		}
	}

}

void Cube::printParams() {

	fprintf( dumpFile, "len = %d;\n", len );

}

void Cube::printCaracteristics() {

	fprintf( dumpFile, "area = %d\n", 6*square(len) );
	fprintf( dumpFile, "volume = %d\n", len*square(len) );

}


