/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of volcompose.

    volcompose is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    volcompose is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with volcompose; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#ifndef FIGURE
#define FIGURE

#include <vol.h>
#include <math.h>
#include <stdio.h>

typedef double number_t;
typedef int coord_t;

//! Abstract class of figure. 
class Figure {
protected:

	FILE				*dumpFile;
	bool				drawAxis;
	
	virtual Vol			initDraw( ) = 0;
	virtual void		endDraw( Vol &v )  = 0;

	virtual	void		defaultMethodDraw( Vol &v ) = 0;

//	typedef void (Figure::*draw_method)(Vol &v);
	
	double				rx, ry, rz; // rotation angles around x, y and z axis.

	// These two functions are not called if dumpFile is NULL
	// (so it's useless to test it)
	virtual void		printParams() = 0;
	virtual void		printCaracteristics() = 0;

public:
	virtual const char *type() = 0;

	Figure( double rx = 0., double ry = 0., double rz = 0. );
	virtual ~Figure() {};

	Vol 				draw( const char *sigFileName = NULL );
	Vol					draw( FILE *sigFile );	

	void				drawWithAxis() { drawAxis = true; }
	void 				drawWithoutAxis() { drawAxis = false; }

};

class ParametricFigure : virtual public Figure {
protected:
	// Methods for parametric draw
	virtual number_t	getMinTheta() 	= 0;
	virtual number_t	getMaxTheta() 	= 0;
	virtual number_t	getMinPhi()		= 0;
	virtual number_t	getMaxPhi()		= 0;
	virtual number_t	getStepTheta() 	{ return (getMaxTheta() - getMinTheta())/300; }
	virtual number_t    getStepPhi() 		{ return (getMaxPhi() - getMinPhi())/300; }

/*	virtual void		get_point( number_t theta, number_t phi, number_t *x, number_t *y, number_t *z, voxel *color ) = 0;

	void				get_point( number_t theta, number_t phi, coord_t *x, coord_t *y, coord_t *z, voxel *color );
m*/
	virtual void		drawPoints( Vol &v, number_t theta, number_t phi ) = 0;

	virtual void		defaultMethodDraw( Vol &v );

public:
	ParametricFigure( ) {};
	virtual ~ParametricFigure() {};
};

class CartesianFigure : virtual public Figure {
protected:
	// Methods for cartesian draw
	virtual	bool		pointIn( coord_t x, coord_t y, coord_t z, voxel *color ) = 0;
	virtual void        defaultMethodDraw( Vol &v );


	virtual coord_t		getMinX( Vol &v ) { return v.minX(); }
	virtual coord_t		getMinY( Vol &v ) { return v.minY(); }
	virtual coord_t		getMinZ( Vol &v ) { return v.minZ(); }
	virtual coord_t		getMaxX( Vol &v ) { return v.maxX(); }
	virtual coord_t		getMaxY( Vol &v ) { return v.maxY(); }
	virtual coord_t		getMaxZ( Vol &v ) { return v.maxZ(); }

public:
	CartesianFigure( ) {};
	virtual ~CartesianFigure() {};
};

class ParametricAndCartesianFigure : public CartesianFigure, public ParametricFigure {
private:
	typedef enum { m_cartesian, m_parametric } mode_t;
	mode_t mode;

protected:
	virtual void 		defaultMethodDraw( Vol &v ) {
		switch (mode) {
			case m_cartesian:
				return CartesianFigure::defaultMethodDraw( v );
			case m_parametric:
				return ParametricFigure::defaultMethodDraw( v );
			}
	}

public:
	ParametricAndCartesianFigure() : mode(m_cartesian) {};
	virtual ~ParametricAndCartesianFigure() {};
	
	void 	setParametricMode() { mode = m_parametric; }
	void	setCartesianMode() { mode = m_cartesian; }
	mode_t	getMode() { return mode; }

};

#endif
