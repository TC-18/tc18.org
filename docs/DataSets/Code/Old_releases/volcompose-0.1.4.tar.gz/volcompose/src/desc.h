/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of volcompose.

    volcompose is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    volcompose is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with volcompose; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#ifndef DESC
#define DESC

#include <string.h>
#include <stdlib.h>
#include <strings.h>
#include <stddef.h>
#include <math.h>
#include <stdio.h>

#define IDENTSIZE 30

extern int yyerror(char *);

typedef char ident_t[IDENTSIZE];

struct Figure;

struct figlist_t {
	Figure *f;
	figlist_t *next;
};


struct paramlist_t {
	char	text[30];
	double	value;
	bool	used;
	
	paramlist_t *next;
};

inline void free_paramlist( paramlist_t* head ) {

	paramlist_t *cur = head;
	
	while (cur) {

		if (!cur->used)
			fprintf( stderr, "Warning: unused argument \"%s\".\n", cur->text );
	
		cur = head->next;
		delete head;
		head = cur;
	}

}

inline int extract_param( paramlist_t* head, const char *name, double *dest ) {

	paramlist_t *cur = head;
	while (cur != NULL) {
		if (strncmp( name, cur->text, 29 ) == 0) {
			*dest = cur->value;
			cur->used = true;
			return 0;
		}

		cur = cur->next;
	}	

	fprintf( stderr, "missing parameter : %s\n", name );
	return 1;
}

extern int line;
extern int col;

extern int yyparse();
extern int yyerror();
extern int yylex();
//extern int yyerror( const char * );

extern const char *voldestfile, *sigdestfile;

enum {
	noError,
	badCommandLine,
	badInputFile,
	badOutputFile,
	badParameters
};

extern int parseErrCode;

#endif
