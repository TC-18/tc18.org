/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of volcompose.

    volcompose is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    volcompose is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with volcompose; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include "ellipsoid.h"
#include "surface.h"
#include "utils.h"

#include <math.h>
#include <stdio.h>
#include <assert.h>
#include <limits.h>
#include <values.h>

Ellipsoid::Ellipsoid( number_t aa, number_t bb, number_t cc, number_t rx, number_t ry, number_t rz ) :
	Figure( rx, ry, rz ),
	a(aa), b(bb), c(cc) {

//	max_Curvature = max( gaussianCurvature( 1, 0, 0 ), max( gaussianCurvature( 0, 1, 0 ), gaussianCurvature( 0, 0, 1 ) ) );
//	max_Curvature = compute_maxCurvature();

	initCurvature();

	if (a < 0 || b < 0 || c < 0 )
		throw InvalidParametersException( "Ellipsoid : all a, b and c must be greater than zero." );

}

number_t Ellipsoid::gaussianCurvature( number_t x, number_t y, number_t z ) {

	number_t h = square(x)/pow(a, 4) + square(y)/pow(b, 4) + square(z)/pow(c, 4);
	h = 1/sqrt(h);
	h = pow(h, 4.)/(square(a)*square(b)*square(c));
	return h;
}

bool Ellipsoid::inEllipsoid( coord_t cox, coord_t coy, coord_t coz ) {
	number_t sx = square(cox);
	number_t sy = square(coy);
	number_t sz = square(coz);
//#endif
	number_t sa = square(a);
	number_t sb = square(b);
	number_t sc = square(c);

	number_t n = sx/sa + sy/sb + sz/sc;
//	return n <= 1.0;
	return n < 1.0;
}

bool Ellipsoid::pointIn( coord_t ax, coord_t ay, coord_t az, voxel *color ) {

	

	// First of all (cox, coy, coz) must be in the ellipsoid !
	if (inEllipsoid( ax, ay, az )) {
	
	
		number_t tab[12][2];
		int i = 0;
		number_t nx = (number_t)ax, ny = (number_t)ay, nz = (number_t)az;
		number_t Curvature = getMaxCurvature() - getMinCurvature();
		
		intersections( ax, ay, az, tab );
	
//		if (Curvature < 1e-15) Curvature = 1;	
		
//		while (i < 24 && !intersectionOf( &nx, &ny, &nz, i++, tab ));
		
//		if (i < 24) {
//			*color = (voxel)(240*gaussianCurvature(nx, ny, nz)/Curvature + 10);
//		} else {
			*color = 0x60;
//		}
	
		if (dumpFile != NULL)
			dumpCartesianPoint( ax, ay, az, tab );
		return true;
	
	}

	return false;

}

void Ellipsoid::initCurvature() {

	min_Curvature = min( gaussianCurvature(a, 0, 0), min( gaussianCurvature(0, b, 0), gaussianCurvature(0, 0, c) ) );
	max_Curvature = max( gaussianCurvature(a, 0, 0), max( gaussianCurvature(0, b, 0), gaussianCurvature(0, 0, c) ) );

}

void Ellipsoid::intersections( coord_t ix, coord_t iy, coord_t iz, number_t res[12][2] ) {


	assert( ix >= 0 && iy >= 0 && iz >= 0 );

//	int add[4][2] = { { 0, 0 }, {1, 0}, {0, 1}, {1, 1} };
	double add[4][2] = { { -0.5, -0.5 }, {0.5, -0.5}, {-0.5, 0.5}, {0.5, 0.5} };
//	double add[4][2] = { {0.5, 0.5}, {1.5, 0.5}, {0.5, 1.5}, {1.5, 1.5} };
/*#ifdef PLUS_HALF
	const number_t cox = (number_t)ix + 0.5, coy = (number_t)iy + 0.5, coz = (number_t)iz + 0.5;
#else
*/
	const number_t cox = ix, coy = iy, coz = iz;
//#endif

	// Solves equations in X
	for (int i = 0; i < 4; ++i) {
		solve( cox, a, coy + add[i][0], b, coz + add[i][1], c, cox, cox + 1, &res[i][0], &res[i][1] );
	}
	// Solves equations in Y
	for (int i = 0;  i < 4; ++i) {
		solve( coy, b, cox + add[i][0], a, coz + add[i][1], c, coy, coy + 1, &res[i + 4][0], &res[i + 4][1] );
	}
	// Solves equations in Z
	for (int i = 0;  i < 4; ++i) {
		solve( coz, c, cox + add[i][0], a, coy + add[i][1], b, coz, coz + 1, &res[i + 8][0], &res[i + 8][1] );
	}

}

void Ellipsoid::solve( number_t V, number_t v, number_t A, number_t aa, number_t B, number_t bb, number_t xmin, number_t xmax, number_t *x1, number_t *x2 ) {

	number_t v2  = square(v);
	number_t e_a = 1/v2;
	number_t e_b = 2*V/v2;
	number_t e_c = square(V)/v2 + square(A)/square(aa) + square(B)/square(bb) - 1;

	number_t delta = square(e_b) - 4*e_a*e_c;
	
	if (delta < 0) {
		*x1 = *x2 = -1;
		return;
	}

	*x1 = (-e_b - sqrt(delta)) / (2*e_a) + V;
	*x2 = (-e_b + sqrt(delta)) / (2*e_a) + V;

	if (*x1 < xmin || *x1 > xmax)
		*x1 = -1;
	if (*x2 < xmin || *x2 > xmax)
		*x2 = -1;

}

bool Ellipsoid::intersectionOf( number_t *x, number_t *y, number_t *z, int inum, number_t intersections[12][2] ) {

	const double S = -2.0;

	// This tab tells us howto use our intersections tab.
	double howto[12][3] = {
		{S, -0.5, -0.5},
		{S, 0.5, -0.5},
		{S, -0.5, 0.5},
		{S, 0.5, 0.5},
		{-0.5, S, -0.5},
		{0.5, S, -0.5},
		{-0.5, S, 0.5},
		{0.5, S, 0.5},
		{-0.5, -0.5, S},
		{0.5, -0.5, S},
		{-0.5, 0.5, S},
		{0.5, 0.5, S}
	};

	if (intersections[inum/2][inum%2] >= 0) {
		*x = (howto[inum/2][0] <= -1) ? intersections[inum/2][inum%2] : *x + howto[inum/2][0];
		*y = (howto[inum/2][1] <= -1) ? intersections[inum/2][inum%2] : *y + howto[inum/2][1];
		*z = (howto[inum/2][2] <= -1) ? intersections[inum/2][inum%2] : *z + howto[inum/2][2];
		return true;
	}
	return false;
}

void Ellipsoid::drawPoints( Vol &v, number_t theta, number_t phi ) {

	coord_t mx = (coord_t)(a * cos( theta ) * sin( phi )); 
	coord_t y = (coord_t)(b * sin( theta ) * sin( phi ));
	coord_t z = (coord_t)(c * cos( phi ));

	for (coord_t x = 0; x < (int)mx; ++x) {
		v( x, y, z ) = 0x60;
	}

}

number_t Ellipsoid::getMaxCurvature() {

	return max_Curvature;

}

number_t Ellipsoid::getMinCurvature() {

	return min_Curvature;

}

Vol Ellipsoid::initDraw( ) {

	number_t m = max( a, max(b, c) );
	if (dumpFile != NULL) {
		fprintf( dumpFile, "X\tY\tZ\tx\ty\tz\tgauss\n");
	}
	return Vol( (int)(m*2 + 1), (int)(m*2 + 1), (int)(m*2 + 1), 0 );

}

void Ellipsoid::endDraw( Vol &v ) {

	v.symetry( a, b, c );

}

void Ellipsoid::printCaracteristics() {

	fprintf( dumpFile, "area = %e\n", area() );

}

void Ellipsoid::printParams() {

	fprintf( dumpFile, "a = %e;\nb= %e;\nc = %e;\n", a, b, c );

}

void Ellipsoid::dumpCartesianPoint( coord_t x, coord_t y, coord_t z, number_t inter[12][2] ) {

	bool first_time = true;
	number_t onx = -1, ony = -1, onz = -1;
	
	for (int i = 0; i < 24; ++i) {
		
#ifdef PLUS_HALF
		number_t nx = (number_t)x + 0.5, ny = (number_t)y + 0.5, nz = (number_t)z + 0.5;
#else
		number_t nx = x, ny = y, nz = z;
#endif
		if (intersectionOf( &nx, &ny, &nz, i, inter ) && (onx != nx || ony != ny || onz != nz)) {
			if (first_time) {
				fprintf( dumpFile, "%d\t%d\t%d\n", x, y, z );
				first_time = false;
			}
			fprintf( dumpFile, "\t\t\t%e\t%e\t%e\t%e\n", nx, ny, nz, gaussianCurvature( nx, ny, nz ) );
			onx = nx, ony = ny, onz = nz;
		}
	}

}

number_t Ellipsoid::area() {
	return EllipsoidArea( a, b, c );
}


