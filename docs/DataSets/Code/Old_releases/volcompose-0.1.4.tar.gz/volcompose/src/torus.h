/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@eric.univ-lyon2.fr> for "Laboratoire ERIC, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@eric.univ-lyon2.fr> for "Laboratoire ERIC, universit� Lyon II, France."

This file is part of voldraw.

    voldraw is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    voldraw is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with voldraw; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#ifndef TORUS
#define TORUS

#include "figure.h"

#define TORUS_IS_CARTESIAN_FIGURE 0
// There is a cartesian equation for the torus but 
// it is not implemented yet how to find true points
// from a discret point, so it is useless ...

class Torus : 
#if TORUS_IS_CARTESIAN_FIGURE
	public ParametricAndCartesianFigure 
#else
	public ParametricFigure 
#endif
{

protected:
	number_t 			a, c;

	// Cartesian (even when we don't want to be a cartesian figure, we need these functions)
	bool				inTorus( coord_t cox, coord_t coy, coord_t coz );

#if TORUS_IS_CARTESIAN_FIGURE
	virtual bool		pointIn( coord_t, coord_t y, coord_t z, voxel *color );
	virtual coord_t		getMinX( Vol &v ) { return 0; }
	virtual coord_t		getMinY( Vol &v ) { return 0; }
	virtual coord_t		getMinZ( Vol &v ) { return 0; }
#endif

	// Parametric
	virtual void		drawPoints( Vol &v, number_t theta, number_t phi );


	
	virtual Vol			initDraw( );
	virtual void		dumpParametricPoint( number_t x, number_t y, number_t z, number_t phi, number_t theta );
	virtual void		endDraw( Vol &v );

	virtual void		printCaracteristics();
	virtual void 		printParams();	

	virtual number_t	area();
	virtual number_t	volume();

	virtual number_t	gaussianCurvature( number_t theta, number_t phi );
	virtual number_t    meanCurvature( number_t theta, number_t phi );

	virtual const char *type() { return "Torus"; }

	int lastx, lasty, lastz;

	
public:
	virtual number_t	getMinTheta() {return 0.0;}
	virtual number_t	getMaxTheta() {return M_PI/2;}
	virtual number_t	getMinPhi() {return 0.0;}
	virtual number_t	getMaxPhi() {return M_PI;}

	// parametric equation : x^2/a^2 + y^2/b^2 + z^2/c^2 == 1
	Torus( number_t a, number_t c, number_t rx = 0.0, number_t ry = 0.0, number_t rz = 0.0 );
	~Torus() {};

};

#endif
