/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@eric.univ-lyon2.fr> for "Laboratoire ERIC, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@eric.univ-lyon2.fr> for "Laboratoire ERIC, universit� Lyon II, France."

This file is part of voldraw.

    voldraw is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    voldraw is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with voldraw; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include "torus.h"
#include "utils.h"

#include <math.h>
#include <stdio.h>
#include <assert.h>
#include <limits.h>
#include <values.h>

Torus::Torus( number_t aa, number_t cc, number_t rx, number_t ry, number_t rz ) :
	Figure( rx, ry, rz ),
	a(aa), c(cc) {

	if (a < 0 || c < 0) {
		throw InvalidParametersException( "Torus : a and c must be greater than zero." );
	}

}

bool Torus::inTorus( coord_t cox, coord_t coy, coord_t coz ) {

	number_t x = (number_t)cox, y = (number_t)coy, z = (number_t)coz;
	number_t n = square(c - sqrt( square(x) + square(y) )) + square(z);
	number_t aa = square(a);

//	return (int)n == (int)aa;
	return n < aa;

}

#if TORUS_IS_CARTESIAN_FIGURE
bool Torus::pointIn( coord_t ax, coord_t ay, coord_t az, voxel *color ) {

	// First of all (cox, coy, coz) must be in the Torus !
	if (inTorus( ax, ay, az )) {
	
		*color = 0x60;
	
//		if (dumpFile != NULL)
//			dumpCartesianPoint( ax, ay, az, tab );
		return true;
	
	}

	return false;

}
#endif

void Torus::drawPoints( Vol &v, number_t theta, number_t phi ) {

	
	number_t mx = (c + a*cos(phi))*cos(theta);
	number_t y = (c + a*cos(phi))*sin(theta);
	number_t z = a*sin(phi);

#if 1
	for (coord_t x = 0; x < (int)mx; ++x) {
		if (inTorus( x, (int)y, (int)z))
			v( x, (int)y, (int)z ) = 0x60;
	}
#else	
	v( (int)mx, (int)y, (int)z ) = 0x60;
#endif

	if (dumpFile != NULL)
		dumpParametricPoint( mx, y, z, theta, phi );

}

Vol Torus::initDraw( ) {

	if (dumpFile != NULL) {
		if (a > c) {
			fprintf( dumpFile, "/* WARNING : This is a spindle torus (a > c) ! Some of the points below may not appear to be on the surface of the torus in the volume file. */\n" );
		}
		fprintf( dumpFile, "X\tY\tZ\tx\ty\tz\tgauss\tmean\n");
	}
	lastx = lasty = lastz = INT_MAX;
	return Vol( 2*(int)(c + a + 1), 2*(int)(c + a + 1), 2*(int)(a + c + 1), 0 ); 

}

void Torus::endDraw( Vol &v ) {

	v.symetry( (int)(c + a), (int)(c + a), (int)a );

}

void Torus::printCaracteristics() {

	fprintf( dumpFile, "area = %e;\nvolume = %e;\n", area(), volume() );

}

void Torus::printParams() {

	fprintf( dumpFile, "a = %e;\nc = %e;\n", a, c );

}

number_t Torus::area() {
	return 4*square(M_PI)*a*c;
}

number_t Torus::volume() {
	return 2*square(M_PI)*square(a)*c;
}

void Torus::dumpParametricPoint( number_t x, number_t y, number_t z, number_t theta, number_t phi ) {

	if (lastx != (int)x || lasty != (int)y || lastz != (int)z) {
		fprintf( dumpFile, "%d\t%d\t%d\n", (int)x, (int)y, (int)z );
		
		lastx = (int)x;
		lasty = (int)y;
		lastz = (int)z;
	}

	fprintf( dumpFile, "\t\t\t%e\t%e\t%e\t%e\t%e\n", x, y, z, gaussianCurvature( theta, phi ), meanCurvature( theta, phi ) );

}

number_t Torus::gaussianCurvature( number_t theta, number_t phi ) {

	// http://www.math.hmc.edu/faculty/gu/curves_and_surfaces/surfaces/torus.html
	return cos(phi)/( c*(a + c*cos(phi) ));	

}

number_t Torus::meanCurvature( number_t theta, number_t phi ) {
	
	return -( a + 2*c*cos(phi) )/(2*c*(a + c*cos(phi) ) );

}
