#!/bin/sh

[ $# != 1 ] && exit 1

if [ "$1" = "-c" ]
then
    date=\"`date`\"
    version=0.1.1
    cat > src/config.h << EOF
DATE=$date
VERSION=$version
EOF
    exit 0  
else 
	sed 's/ /\\ /g' makefile.in > /tmp/make.$$.in
	. /tmp/make.$$.in
	. ./src/config.h || exit 1
	rm -f /tmp/make.$$.in
fi

PREFIX=$1

mkdir -p $PREFIX
mkdir -p $PREFIX/bin
mkdir -p $PREFIX/include
mkdir -p $PREFIX/lib
mkdir -p $PREFIX/man/man1
mkdir -p $PREFIX/share/doc

mkdir -p tmp
mkdir -p tmp/bin
mkdir -p tmp/include
mkdir -p tmp/lib
mkdir -p tmp/man/man1
mkdir -p tmp/share/doc


if [ -n "$MAKE_VOLCOMPOSE" ]
then	
	cp src/volcompose tmp/bin
	cp src/man1/volcompose.1 tmp/man/man1
else
	cp src/man1/uninstalled-volcompose.1 tmp/man/man1/volcompose.1
fi

cp src/volgen tmp/bin
cp src/man1/volgen.1 tmp/man/man1
cp -rf src/doc tmp/share/doc/volcompose

find tmp -name "*.html" -o -name "*.1" -o -name "*.7" -o -name Doxyfile | \
while read m ; \
do \
	echo updating $m ; \
	sed "s/__DATE__/$DATE/g;s/__VERSION__/$VERSION/g" "$m" > /tmp/m.$$ && mv /tmp/m.$$ $m ; \
done   

cp tmp/bin/* $PREFIX/bin
cp tmp/man/man1/* $PREFIX/man/man1
cp -fr tmp/share/doc/* $PREFIX/share/doc/volcompose

echo > uninstall.sh << EOF
#!/bin/sh
# This is a generated uninstall script
rm -f $PREFIX/bin/volgen $PREFIX/bin/volcompose
rm -f $PREFIX/man/man1/volcompose.1 $PREFIX/man/man1/volgen.1
rm -rf $PREFIX/share/doc/volcompose
EOF
chmod +x uninstall.sh

rm -rf tmp
