/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of volcompose.

    volcompose is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    volcompose is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with volcompose; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/
#include <vol.h>

#include "sphere.h"
#include "ellipsoid.h"
#include "cube.h"
#include "rounded-cube.h"
#include "catenoid.h"

//#include "torus.h"

#include "desc.h"

void usage( int errcode = 1) {
	
	fprintf( stderr, 
"Usage:\n\
\tvolgen figure params [ -v output vol file ] [ -s output sig file ] [-axis]\n\
\n\
\t+---------------+----------------------------+\n\
\t| Figure        | Parameters                 |\n\
\t+---------------+----------------------------+\n\
\t| ellipsoid     | -a float -b float -c float |\n\
\t| sphere        | -r float                   |\n\
\t| cube          | -len integer               |\n\
\t| rounded-cube  | -len integer               |\n\
\t| catenoid      | -c float                   |\n\
\t| torus         | -a float -c float          |\n\
\t+---------------+----------------------------+\n\
\n\
\tAdditionnal parameters : -rx float -ry float -rz float\n\
\t(rotation in radian around axis X, Y and Z).\n\
\t\n\
\t-v output vol file : default /dev/null. \"-\" means stdout.\n\
\t-s output sig file : default /dev/null. \"-\" means stdout.\n\
\t\n\
\t-axis              : draw axis\n\
\t-parametric        : draw with parametric equation (if available)\n\
\t-cartesian         : draw with cartesian equation (if available)\n\
");
	exit( errcode );

}

typedef enum {
	m_normal = 0,
	m_parametric,
	m_cartesian,

	numModes
} drawmode_t;

static char *mode_txt[] = {"default", "parametric", "cartesian" };

Vol makeEllipsoid( paramlist_t *p, double r[3], drawmode_t = m_normal );
Vol makeSphere( paramlist_t *p, double r[3], drawmode_t = m_normal );
Vol makeCube( paramlist_t *p, double r[3], drawmode_t = m_normal );
Vol makeCatenoid( paramlist_t *p, double r[3], drawmode_t = m_normal );
Vol makeRoundedCube( paramlist_t *p, double r[3], drawmode_t = m_normal );
//Vol makeTorus( paramlist_t *p, double r[3], drawmode_t = m_normal );

typedef Vol (*volmaker_t)( paramlist_t *p, double r[3], drawmode_t );

struct factoryelt_t {
	const char *type;
	volmaker_t	func;
}; 

static factoryelt_t volFactory[] = {
		{"sphere", makeSphere },
		{"ellipsoid", makeEllipsoid },
		{"cube", makeCube },
		{"rounded-cube", makeRoundedCube },
		{"catenoid", makeCatenoid }/*,
		{"torus", makeTorus }*/
	};

static const int nbMakers = sizeof( volFactory )/sizeof( factoryelt_t );

const char *voldestfile = NULL, *sigdestfile = NULL;

int main( int argc, char **argv ) {

	volmaker_t  maker = NULL;
	double		rotation[] = {0.0, 0.0, 0.0};
	bool axis = false;
	
	if (argc < 4) {
		usage();
	}

	if (strcmp( argv[1], "-h" ) == 0 || strcmp( argv[1], "--help" ) == 0) {
		usage( 0 );
	}
	
	for (int i = 0; i < nbMakers; ++i) {
		if (strcmp( volFactory[i].type, argv[1] ) == 0) {
			maker = volFactory[i].func;
			break;
		}
	}
	if (maker == NULL) {
		fprintf( stderr, "%s : no such type !\n", argv[1] );
		usage();
	}

	drawmode_t mode = m_normal;
	paramlist_t *head = NULL;
	for (int i = 2; i < argc; ++i) {
	
		if (argv[i][0] != '-')
			usage();
	
		// Options without arg
		if (strcmp( argv[i], "-axis" ) == 0) {
			axis = true;
		} else if (strcmp( argv[i], "-parametric" ) == 0) {
			mode = m_parametric;
		} else if (strcmp( argv[i], "-cartesian" ) == 0) {
			mode = m_cartesian;
		} else {

			// Options with arg
		
			if (i+1 >= argc || (strlen(argv[i + 1]) > 1 && argv[i + 1][0] == '-'))
				usage( );
	
			// txt arg
			if (strcmp( "-v", argv[i] ) == 0) {
				voldestfile = strcmp( argv[i + 1], "-" ) == 0 ? "/dev/stdout" : argv[i + 1];
			} else if (strcmp( "-s", argv[i] ) == 0) {
				sigdestfile = strcmp( argv[i + 1], "-" ) == 0 ? "/dev/stdout" : argv[i + 1];	
			} else {
		
				// Arguments that take number
				double value;	
				if (sscanf( argv[i + 1], "%le", &value ) != 1) {
					fprintf( stderr, "Invalid number : %s !\n", argv[i + 1] );
					usage();
				}
				if (argv[i + 1][strlen(argv[i + 1]) - 1] == 'd') {
					value *= 2*M_PI/360.;
				}
				
				if (strcmp( "-rx", argv[i] ) == 0) {
					rotation[0] = value;
				} else if (strcmp( "-ry", argv[i] ) == 0) {
					rotation[1] = value;
				} else if (strcmp( "-rz", argv[i] ) == 0) {
					rotation[2] = value;
				} else if (strncmp( "-", argv[i], 1 ) == 0) {
					// FIXME : check new
					paramlist_t *newhead = new paramlist_t;
					strncpy( newhead->text, argv[i] + 1, 29 );
					newhead->value = value;
					newhead->next = head;
					newhead->used = false;
					head = newhead;
				} else {
					usage();
				}
			}
			// skip argument !
			++i;
		}
	}

	if (head == NULL) {
		fprintf( stderr, "No parameters found !\n" );
		usage();
	}
	Vol v = (*maker)( head, rotation, mode );

	free_paramlist( head );
	
	if (axis)
		v.drawAxis();
	if (voldestfile != NULL)
		v.dumpVol( voldestfile );

	return 0;
}

Vol makeSphere( paramlist_t *p, double rot[3], drawmode_t mode ) {

	double r;
	int ret = 0;
	
	ret += extract_param( p, "r", &r );
	if (ret != 0) {
		fprintf( stderr, "Sphere : invalid parameters !\n" );
		usage( 2 );
	}
	return Sphere( r, rot[0], rot[1], rot[2] ).draw( sigdestfile );

}

void setMode( Figure *fig, drawmode_t m ) {

	if (m != m_normal) {

		ParametricAndCartesianFigure *p = dynamic_cast<ParametricAndCartesianFigure*>( fig );
		
		if (p == NULL) {
			fprintf( stderr, "Warning : mode %s nor available for %s. Back to default mode.\n",
			        (m >= m_normal && m < numModes) ? mode_txt[m] : "<invalid>", fig->type() );
		} else {
			switch (m) {
				case m_parametric:
					p->setParametricMode();
					break;
				case m_cartesian:
					p->setCartesianMode();
					break;
				default:
					fprintf( stderr, "Mode %d not found !\n", m );
			}
		}
	}
}



Vol makeEllipsoid( paramlist_t *p, double rot[3], drawmode_t mode ) {

	double a, b, c;
	int ret = 0;

	ret += extract_param( p, "a", &a );
	ret += extract_param( p, "b", &b );
	ret += extract_param( p, "c", &c );
	if (ret != 0) {
		fprintf( stderr, "Ellipsoid : invalid parameters !\n" );
		usage( 2 );
	}

	Ellipsoid e( a, b, c, rot[0], rot[1], rot[2]  );
	setMode( &e, mode );	
	return e.draw( sigdestfile );

}

Vol makeCube( paramlist_t *p, double rot[3], drawmode_t mode ) {

	double len;
	int ret = 0;

	ret += extract_param( p, "len", &len );
	if (ret != 0) {
		fprintf( stderr, "Cube : invalid parameters !\n" );
		usage( 2 );
	}

	Cube c( (int)len, rot[0], rot[1], rot[2] );
	setMode( &c, mode );
	return c.draw( sigdestfile );

}

Vol makeRoundedCube( paramlist_t *p, double rot[3], drawmode_t mode ) {

	double len;
	int ret = 0;

	ret += extract_param( p, "len", &len );
	if (ret != 0) {
		fprintf( stderr, "RoundedCube : invalid parameters !\n" );
		usage( 2 );
	}

	RoundedCube r( (int)len, rot[0], rot[1], rot[2] );
	setMode( &r, mode );
	return r.draw( sigdestfile );

}

Vol makeCatenoid( paramlist_t *p, double rot[3], drawmode_t mode ) {

	double c;
	int ret = 0;

	ret += extract_param( p, "c", &c );
	if (ret != 0) {
		fprintf( stderr, "Catenoid : invalid parameters !\n" );
		usage( 2 );
	}

	Catenoid ca( c, rot[0], rot[1], rot[2] );
	setMode( &ca, mode );
	return ca.draw( sigdestfile );

}

/*
Vol makeTorus( paramlist_t *p, double rot[3], drawmode_t mode ) {

	double a, c;
	int ret = 0;

	ret += extract_param( p, "a", &a );
	ret += extract_param( p, "c", &c );
	if (ret != 0) {
		fprintf( stderr, "Torus : invalid parameters !\n" );
		usage( 2 );
	}

	Torus t( a, c, rot[0], rot[1], rot[2] );
	setMode( &t, mode );
	return t.draw( sigdestfile );

}
*/
