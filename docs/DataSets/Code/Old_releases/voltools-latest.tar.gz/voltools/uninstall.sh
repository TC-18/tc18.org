#!/bin/sh
# This is a generated uninstall script
rm -f /home/alexis/local/bin/volboundary /home/alexis/local/bin/volheader /home/alexis/local/bin/vol2geom /home/alexis/local/bin/raw2vol /home/alexis/local/bin/vol2raw
rm -f /home/alexis/local/man/man1/volboundary.1 /home/alexis/local/man/man1/volheader.1 /home/alexis/local/man/man1/vol2geom.1 /home/alexis/local/man/man1/raw2vol.1 /home/alexis/local/man/man1/vol2raw.1
