#ifndef TOOLS_H
#define TOOLS_H

// error codes
const int 	noError = 0, 			// OK!
			badCommandLine = 1,	
			badInputFile = 2,		
			badOutputFile = 3;		

#endif
