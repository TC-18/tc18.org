/*
Copyright 2002, 2003 Alexis Guillaume <aguillau@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."
Copyright 2002, 2003 David Coeurjolly <dcoeurjo@liris.univ-lyon2.fr> for "Laboratoire LIRIS, universit� Lyon II, France."

This file is part of voltools.

    voltools is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    voltools is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with voltools; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <vol.h>
#include "tools.h"

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>


void usage( int errcode = badCommandLine ) {

	fprintf( stderr, 
"Usage :\n\
	raw2vol -x number -y number -z number [ -i inputfile ] [ -o outputfile ] [ -a alphacolor ]\n\
" );
	
	exit( errcode );

}

int main( int argc, char **argv ) {

	char *infile = "/dev/stdin";
	char *outfile = "/dev/stdout";

	int curoption;
	int alpha = 0;

	int sx = -1, sy = -1, sz = -1;
	
	while ((curoption = getopt( argc, argv, "x:y:z:i:o:a:h" )) != -1) {
		switch (curoption) {
			case 'i':
				infile = optarg;
				break;
			case 'o':
				outfile = optarg;
				break;
			case 'a':
				for (int i = 0; optarg[i]; ++i) {
					if (!isdigit( optarg[i] )) {
						fprintf( stderr, "%s : invalid number !\n", optarg );
						exit( 1 );
					}
				}
				alpha = atoi( optarg );
				if (alpha < 0 || alpha > 0xFF) {
					fprintf( stderr, "%s : invalid number ! (it must be between 0 and 255\n", optarg );
					return badCommandLine;
				}
				break;
			case 'h':
				usage( noError );
				break;
			case 'x': sx = atoi( optarg ); break;
			case 'y': sy = atoi( optarg ); break;
			case 'z': sz = atoi( optarg ); break;
			
		}
	}

	if (optind != argc) {
		usage();
	}

	if (sx == -1 || sy == -1 || sz == -1 ) {
		fprintf( stderr, "You must set the size of the volume with -x, -y, -z.\n" );
		return badCommandLine;
	}
	
	Vol vin( infile, sx, sy, sz, alpha );	
	if (!vin.isOK()) {
		fprintf( stderr, "raw2vol : can't load raw file %s\n", infile );
		exit( badInputFile );
	}
	return vin.dumpVol( outfile ) != 0 ? badOutputFile : noError;
}
